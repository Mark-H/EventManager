<?php
require_once (dirname(dirname(__FILE__)) . '/events.class.php');
class Events_mysql extends Events {}