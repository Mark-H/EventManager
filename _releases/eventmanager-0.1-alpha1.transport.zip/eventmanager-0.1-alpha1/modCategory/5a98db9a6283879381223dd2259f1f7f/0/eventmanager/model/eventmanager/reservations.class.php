<?php
class Reservations extends xPDOObject {}