<?php
require_once (dirname(dirname(__FILE__)) . '/reservations.class.php');
class Reservations_mysql extends Reservations {}