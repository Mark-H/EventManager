<?php
class Events extends xPDOObject {}